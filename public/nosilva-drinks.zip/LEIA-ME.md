# No Silva Drinks — Instalação na VPS (Ubuntu)

Loja online + painel administrativo (/admin) com PostgreSQL.
Fica numa pasta própria, usa um banco próprio e uma porta interna própria (3010).
**Não mexe no outro site, no NGINX dele nem no SSL existente.**

---

## Passo 1 — Enviar a pasta para a VPS

No seu computador (troque `usuario@IP`):

```bash
scp nosilva-drinks.zip usuario@IP:/tmp/
```

Na VPS:

```bash
sudo apt-get install -y unzip
sudo mkdir -p /var/www/nosilva-drinks
sudo unzip /tmp/nosilva-drinks.zip -d /var/www/nosilva-drinks
cd /var/www/nosilva-drinks
```

## Passo 2 — Rodar o instalador

```bash
sudo bash install.sh
```

Ele faz sozinho: instala Node.js e PostgreSQL **só se ainda não existirem**, cria o banco `nosilva`
(separado dos outros), gera senhas seguras no arquivo `.env`, cria as tabelas e deixa o site
rodando com PM2 (volta sozinho se a VPS reiniciar).

No final ele mostra **o e-mail e a senha inicial do painel**. Anote.

> Se a porta 3010 já estiver ocupada: `sudo PORT=3020 bash install.sh`
> (e use 3020 no arquivo do NGINX abaixo).

## Passo 3 — Ligar um endereço ao site (escolha UMA opção)

### Opção A — Domínio ou subdomínio próprio (ex.: `drinks.seusite.com.br`)
1. No painel do seu domínio, crie um registro **A** apontando `drinks` para o IP da VPS.
2. Na VPS:
```bash
sudo cp nginx-subdominio.conf /etc/nginx/sites-available/nosilva
sudo nano /etc/nginx/sites-available/nosilva      # troque drinks.seusite.com.br pelo seu
sudo ln -s /etc/nginx/sites-available/nosilva /etc/nginx/sites-enabled/nosilva
sudo nginx -t && sudo systemctl reload nginx
sudo certbot --nginx -d drinks.seusite.com.br     # SSL só deste endereço
```

### Opção B — Dentro do site atual, em `https://seusite.com.br/drinks/`
Usa o mesmo SSL que já existe, sem alterá-lo.
Abra o arquivo do site atual em `/etc/nginx/sites-available/`, cole o conteúdo de
`nginx-subpasta.conf` dentro do bloco `server { ... }` que tem `listen 443 ssl` e rode:
```bash
sudo nginx -t && sudo systemctl reload nginx
```

## Passo 4 — Primeiro acesso

1. Entre em `.../admin` com o e-mail e senha do Passo 2.
2. **Configurações**: número do WhatsApp que recebe os pedidos, horários, logo, banner. Troque a senha.
3. **Bairros e taxas**: cadastre os bairros atendidos.
4. **Produtos**: cadastre os produtos (foto por arquivo, Ctrl+V ou URL).
5. **Estoque → + Entrada**: registre as compras de mercadoria.

---

## Comandos úteis

| O quê | Comando |
|---|---|
| Ver se está rodando | `pm2 status` |
| Ver erros | `pm2 logs nosilva-drinks` |
| Reiniciar | `pm2 restart nosilva-drinks` |
| Backup do banco | `sudo -u postgres pg_dump nosilva > backup-$(date +%F).sql` |
| Restaurar backup | `sudo -u postgres psql nosilva < backup.sql` |

**Backup automático diário** (guarda 14 dias):
```bash
sudo mkdir -p /var/backups/nosilva
echo '0 3 * * * postgres pg_dump nosilva | gzip > /var/backups/nosilva/$(date +\%F).sql.gz && find /var/backups/nosilva -mtime +14 -delete' | sudo tee /etc/cron.d/nosilva-backup
```

## Atualizar o sistema no futuro
Substitua os arquivos (mantendo `.env` e `public/uploads/`) e rode:
```bash
npm install --omit=dev && npm run init-db && pm2 restart nosilva-drinks
```

## Estrutura
```
src/server.js        servidor e API
db/schema.sql        tabelas do banco
scripts/init-db.js   cria tabelas e o admin
public/              loja (index.html, store.js, style.css)
public/admin/        painel administrativo
public/uploads/      imagens enviadas pelo painel
```

## Como os números do financeiro são calculados
- **Faturamento bruto** = produtos + taxas de entrega dos pedidos confirmados.
- **CMV** = custo de cada produto *no momento da venda* (vendas antigas não mudam se o custo mudar).
- **Lucro bruto** = receita de produtos − CMV.
- **Resultado líquido** = lucro bruto + entregas + outras receitas − despesas operacionais.
- Compras de estoque saem do caixa, mas **não** são descontadas de novo do lucro.
- Pedidos do site entram como "Aguardando confirmação" e só baixam o estoque ao confirmar
  (uma única vez). Cancelar um pedido confirmado devolve o estoque.
